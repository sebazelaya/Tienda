</div>
<footer class="site-footer border-top">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <div class="row">
              <div class="col-md-12">
                <h3 class="footer-heading mb-4">Navegacion</h3><!--Arreglar navegacion-->
              </div>
              <div class="col-md-6 col-lg-4">
                <ul class="list-unstyled">
                  <li><a href="<?= base_url();?>index.php/Home">Inicio</a></li>
                  <li><a href="<?= base_url() ?>index.php/Home/informacion">Acerca de nosotros</a></li>
                </ul>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-3">
            <div class="block-5 mb-5">
              <h3 class="footer-heading mb-4">Para mas informacion</h3>
              <ul class="list-unstyled">
                <li class="address">Santa teresa #430, Los andes ,Valparaiso</li>
                <li class="phone"></li>
                <li class="email">Pinguerbike.cl</li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </footer>
  </div>

  <script src="<?= base_url() ?>/plantilla/js/jquery-3.3.1.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/jquery-ui.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/popper.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/bootstrap.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/owl.carousel.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/jquery.magnific-popup.min.js"></script>
  <script src="<?= base_url() ?>/plantilla/js/aos.js"></script>

  <script src="<?= base_url() ?>/plantilla/js/main.js"></script>

  </body>
</html>
