

<div class="site-blocks-cover aos-init aos-animate" style="background-image: url(https://www.lavanguardia.com/r/GODO/LV/p3/WebSite/2016/07/06/Recortada/APTOPIX_France_Cycling_Tour_de_France-0ca3a_20160705175554-k6sE-U403004950755PsH-992x558@LaVanguardia-Web.jpg);" data-aos="fade">
      <div class="container">
        <div class="row align-items-start align-items-md-center justify-content-end">
          <div class="col-md-4 text-center text-md-left pt-6 pt-md-12">
            	<h1 class="mb-3" style="color:white;">Encuentra lo mejor del ciclismo </h1>
            	<div class="intro-text text-center text-md-left">
              	<h3 class="mb-5" style="color:ivory">Pinguerbike ahora online</h3>
              	<p>

			  	</p>
            </div>
          </div>
        </div>
      </div>
	</div>




    <div class="site-section block-3 site-blocks-2 bg-light">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-7 site-section-heading text-center pt-4">
            <h2>Quienes somos </h2>
          </div>
        </div>
		<br>


    <body>
    <p>
      <center>
    <h2><b>Somos una tienda dedicada al ciclismo con mas de 30 años de experiencia que brinda sus servicios a todo el valle del aconcagua </b></h2>
    </center
    </p>





    </body>


		</div>
